export const environment = {
  apiUrl: 'https://concesionarios-service.onrender.com',
  production: true
};

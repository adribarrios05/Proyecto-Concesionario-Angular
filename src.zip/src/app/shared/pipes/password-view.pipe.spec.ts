import { PasswordViewPipe } from './password-view.pipe';

describe('PasswordViewPipe', () => {
  it('create an instance', () => {
    const pipe = new PasswordViewPipe();
    expect(pipe).toBeTruthy();
  });
});

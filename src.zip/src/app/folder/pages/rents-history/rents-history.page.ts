import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rents-history',
  templateUrl: './rents-history.page.html',
  styleUrls: ['./rents-history.page.scss'],
  standalone: false
})
export class RentsHistoryPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
